# seg2105-f21-lab3-William-67

Lixiong Wei
300145970
lab3 SimpleCalculator
