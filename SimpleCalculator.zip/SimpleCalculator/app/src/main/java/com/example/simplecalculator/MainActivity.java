package com.example.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;

import org.mariuszgromada.math.mxparser.*;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.service.autofill.OnClickAction;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import javax.xml.xpath.XPathExpression;

public class MainActivity extends AppCompatActivity {

    EditText working;
    EditText results;

//    String work = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initTextView();


        working.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getString(R.string.working).equals(working.getText().toString())){
                    working.setText("");
                }
            }
        });
    }


    @SuppressLint("SetTextI18n")
    private void updateText(String str){
        String oldstr = working.getText().toString();
        int curpos = working.getSelectionStart();
        String left = oldstr.substring(0,curpos);
        String right = oldstr.substring(curpos);
        if (getString(R.string.working).equals(working.getText().toString())){
            working.setText(str);
        }else{
            working.setText(left+str+right);
        }
        working.setSelection(curpos+1);

    }

    @SuppressLint("SetTextI18n")
    public void delOnClick(View view){
        String oldstr = working.getText().toString();
        int pos = working.getSelectionStart();
        int textLength = oldstr.length();
        if( (pos!=0 &textLength!=0)){
            if (pos!=textLength){
                if (pos!=1){
                    String left = oldstr.substring(0,pos-1);
                    String right = oldstr.substring(pos);
                    working.setText(left+right);
                }else{
                    String right = oldstr.substring(pos);
                    working.setText(right);
                }
            }else{
                if (textLength==1){
                    working.setText("");
                }else{
                    String left = oldstr.substring(0,pos-1);
                    working.setText(left);
                }
            }
            working.setSelection(pos-1);
        }
    }

    private void initTextView(){
        working = (EditText) findViewById(R.id.WorkingEdit);
        working.setShowSoftInputOnFocus(false);
        results = (EditText) findViewById(R.id.resultEdit);
    }

    public void oneOnClick(View view){
        updateText("1");
    }
    public void twoOnClick(View view){
        updateText("2");
    }
    public void threeOnClick(View view){
        updateText("3");
    }
    public void fourOnClick(View view){
        updateText("4");
    }
    public void fiveOnClick(View view){
        updateText("5");
    }
    public void sixOnClick(View view){
        updateText("6");
    }
    public void sevenOnClick(View view){
        updateText("7");
    }
    public void eightOnClick(View view){
        updateText("8");
    }
    public void nineOnClick(View view){
        updateText("9");
    }
    public void zeroOnClick(View view){
        updateText("0");
    }
    public void minusOnClick(View view){
        updateText("-");
    }
    public void plusOnClick(View view){
        updateText("+");
    }
    public void divOnClick(View view){
        updateText("/");
    }
    public void mulOnClick(View view){
        updateText("*");
    }
    public void powOnClick(View view){
        updateText("^");
    }
    public void perOnClick(View view){
        updateText("%");
    }
    public void dotOnClick(View view){
        updateText(".");
    }

    public void bracketOnClick(View view){
        int pos = working.getSelectionStart();
        //check num of open and close parathensis
        int open = 0;
        int close = 0;
        String str = working.getText().toString();
        int textLength = str.length();
        if (str.equals("")){
            updateText("(");
        }else{
            for (int i =0;i<pos;i++){
                if (str.charAt(i) == '('){
                    open++;
                }
                if (str.charAt(i) == ')'){
                    close++;
                }
            }
            if (open == close | str.charAt(textLength - 1) == '(') {
                updateText("(");
                working.setSelection(pos+1);
            }
            else if (open > close & str.charAt(textLength - 1) != '(') {
                updateText(")");
                working.setSelection(pos+1);
            }
        }

    }
    public void clrOnClick(View view){
        working.setText("");
    }


    public void eqlOnClick(View view){
        String expression = working.getText().toString();

        StringBuffer buffer = new StringBuffer();
        for (int i =0;i<expression.length()-1;i++){
            String str = expression.substring(i,i+1);
            String next = expression.substring(i+1,i+2);
            if (isNumber(str)&isNumber(next)|isNumber(str)&next.equals(".")|isNumber(next)&str.equals(".")){
                buffer.append(str);
            }else if ( (isNumber(str)&!isNumber(next)) || (!isNumber(str))){
                buffer.append(str).append(" ");
            }
        }
        buffer.append(expression.substring(expression.length()-1,expression.length()));

        Expression expression1 = new Expression(buffer.toString());
        double a = expression1.calculate();

        if (isInt(a)){
            int b = (int)a;
            String result = String.valueOf(b);
            results.setText(result);
        }else{
            String result = String.valueOf(a);
            results.setText(result);
        }
    }
    public boolean isNumber(String num){
        return num.equals("0")|num.equals("1")|num.equals("2")|num.equals("3")|num.equals("4")|num.equals("5")|num.equals("6")|num.equals("7")|num.equals("8")|num.equals("9");
    }
    public boolean isInt(double value){
        double b =value ;
        int b1 = (int) b;
        return b % b1 == 0;
    }









}